// buyBackBurnV2.ts
// Ethers v6 wrapper for BuyBackBurnV2 (UUPS). Uses the PROXY address.

import { ethers } from "ethers";

/** Base mainnet */
export const CHAIN_ID = 8453;
/** Proxy address (use this for all interactions) */
export const BUYBACK_PROXY = "0x261E50046C16B6f8d1C9AD01EcB5C31e680e0d4f" as const;

/** Minimal ABI (only what we call/read) */
const ABI = [
  // writes
  "function executeBuyBackBurn(uint256 usdcAmountIn) external",
  "function adjustUsdcToRwaRoute(bool stable, address _aerodromeFactory) external",
  "function setMaxSlippageBps(uint256 newMaxSlippageBps) external",
  "function pause() external",
  "function unpause() external",
  "function emergencyWithdraw() external",

  // reads
  "function getTotalBurnedRwaAmount() view returns (uint256)",
  "function s_usdc() view returns (address)",
  "function s_rwaToken() view returns (address)",
  "function s_companyWallet() view returns (address)",
  "function s_aerodromeFactory() view returns (address)",
  "function router() view returns (address)",
  "function maxSlippageBps() view returns (uint256)",
  // Route[] getter
  "function s_usdcToRwa(uint256) view returns (address from, address to, bool stable, address factory)",

  // AccessControl helpers
  "function hasRole(bytes32 role, address account) view returns (bool)",
  "function DEFAULT_ADMIN_ROLE() view returns (bytes32)"
] as const;

const ERC20_ABI = [
  "function balanceOf(address) view returns (uint256)",
  "function decimals() view returns (uint8)",
  "function transfer(address to, uint256 amount) returns (bool)"
] as const;

export type BuyBackContract = ethers.Contract;

/** Get contract instance with a signer or provider */
export function getBuyBackContract(
  signerOrProvider: ethers.Signer | ethers.Provider,
  address: string = BUYBACK_PROXY
): BuyBackContract {
  return new ethers.Contract(address, ABI, signerOrProvider);
}

/** (Browser) get signer from window.ethereum */
export async function getBrowserSigner() {
  // @ts-ignore
  const provider = new ethers.BrowserProvider(window.ethereum);
  await provider.send("eth_requestAccounts", []);
  const signer = await provider.getSigner();
  return { provider, signer };
}

/* ----------------------- Read helpers ----------------------- */

export async function getTotalBurned(provider: ethers.Provider, addr = BUYBACK_PROXY) {
  const c = getBuyBackContract(provider, addr);
  const v: bigint = await c.getTotalBurnedRwaAmount();
  return v; // bigint (raw 18 decimals)
}

/** Optional: read any ERC20 balance */
export async function readErc20Balance(
  provider: ethers.Provider,
  token: string,
  holder: string
) {
  const erc = new ethers.Contract(token, ERC20_ABI, provider);
  const [bal, dec] = await Promise.all([erc.balanceOf(holder), erc.decimals()]);
  return { balance: bal as bigint, decimals: Number(dec) };
}

/* ----------------------- Write helpers (need roles) ----------------------- */
//Admin role's address: 0x33F271ddb91Bf9FC7Be464e9B0ACC92f6f2aa210

export async function execBuyBackBurn(signer: ethers.Signer, usdcAmountInRaw: bigint, addr = BUYBACK_PROXY) {
  const c = getBuyBackContract(signer, addr);
  const tx = await c.executeBuyBackBurn(usdcAmountInRaw);
  return tx.wait();
}   //call this function to execute buyback and burn

export async function setMaxSlippage(signer: ethers.Signer, bps: number, addr = BUYBACK_PROXY) {
  const c = getBuyBackContract(signer, addr);
  const tx = await c.setMaxSlippageBps(bps);
  return tx.wait();
}

export async function adjustRoute(
  signer: ethers.Signer,
  stable: boolean,
  aerodromeFactory: string,
  addr = BUYBACK_PROXY
) {
  const c = getBuyBackContract(signer, addr);
  const tx = await c.adjustUsdcToRwaRoute(stable, aerodromeFactory);
  return tx.wait();
}

export async function pauseContract(signer: ethers.Signer, addr = BUYBACK_PROXY) {
  const c = getBuyBackContract(signer, addr);
  const tx = await c.pause();
  return tx.wait();
}

export async function unpauseContract(signer: ethers.Signer, addr = BUYBACK_PROXY) {
  const c = getBuyBackContract(signer, addr);
  const tx = await c.unpause();
  return tx.wait();
}

export async function emergencyWithdrawAll(signer: ethers.Signer, addr = BUYBACK_PROXY) {
  const c = getBuyBackContract(signer, addr);
  const tx = await c.emergencyWithdraw();
  return tx.wait();
}
