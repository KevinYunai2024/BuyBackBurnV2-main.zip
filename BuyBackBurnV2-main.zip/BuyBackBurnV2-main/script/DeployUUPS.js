const { ethers, upgrades } = require("hardhat");

async function main() {
    const USDC = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913";
    const RWA = "0xE2B1dc2D4A3b4E59FDF0c47B71A7A86391a8B35a";
    const AERO_ROUTER = "0xcF77a3Ba9A5CA399B7c97c74d54e5b1Beb874E43";
    const COMPANY_WALLET = "0x33F271ddb91Bf9FC7Be464e9B0ACC92f6f2aa210";
    const AERO_FACTORY =  "0x420DD381b31aEf6683db6B902084cB0FFECe40Da";

    if (!USDC || !RWA || !COMPANY_WALLET || !AERO_ROUTER || !AERO_FACTORY) {
        throw new Error("Missing env vars: USDC/RWA/COMPANY_WALLET/AERO_ROUTER");
    }

    console.log("Deploying BuyBackBurnV2 (UUPS proxy) with params:");
    console.log({ USDC, RWA, COMPANY_WALLET, AERO_ROUTER,AERO_FACTORY });
    const Factory = await ethers.getContractFactory("BuyBackBurnV2");
    const proxy = await upgrades.deployProxy(
        Factory,
        [USDC, RWA, COMPANY_WALLET, AERO_ROUTER,AERO_FACTORY],
        { kind: "uups", initializer: "initialize" }
    );
    await proxy.waitForDeployment();

    const proxyAddr = await proxy.getAddress();
    const implAddr = await upgrades.erc1967.getImplementationAddress(proxyAddr);
    const adminAddr = await upgrades.erc1967.getAdminAddress(proxyAddr);

    console.log("Proxy:", proxyAddr);
    console.log("Impl :", implAddr);
    console.log("Admin:", adminAddr);

    const c = await ethers.getContractAt("BuyBackBurnV2", proxyAddr);
    const burned = await c.getTotalBurnedRwaAmount();
    console.log("TotalBurnedRwa:", burned.toString());
}

main().catch((e) => {
    console.error(e);
    process.exit(1);
})