### Slither:
INFO:Slither:slither.config.json has an unknown key: exclude_paths : ['node_modules/', 'test/', 'lib/']
'npx hardhat clean' running (wd: /root/RWAInc-Projects/BuyBackAndBurnV2)
'npx hardhat clean --global' running (wd: /root/RWAInc-Projects/BuyBackAndBurnV2)
'npx hardhat compile --force' running (wd: /root/RWAInc-Projects/BuyBackAndBurnV2)
ERROR:ContractSolcParsing:Impossible to generate IR for BuyBackBurnV2.executeBuyBackBurn (contracts/BuyBackBurnV2.sol#40-66):
 'NoneType' object has no attribute 'parameters'
INFO:Detectors:
ERC1967Utils.upgradeToAndCall(address,bytes) (node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Utils.sol#67-76) ignores return value by Address.functionDelegateCall(newImplementation,data) (node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Utils.sol#72)
ERC1967Utils.upgradeBeaconToAndCall(address,bytes) (node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Utils.sol#157-166) ignores return value by Address.functionDelegateCall(IBeacon(newBeacon).implementation(),data) (node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Utils.sol#162)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#unused-return
INFO:Detectors:
BuyBackBurnV2.initialize(address,address,address,address)._routerAddr (contracts/BuyBackBurnV2.sol#96) lacks a zero-check on :
                - routerAddr = _routerAddr (contracts/BuyBackBurnV2.sol#101)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#missing-zero-address-validation
INFO:Detectors:
AccessControlUpgradeable._getAccessControlStorage() (node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol#68-72) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol#69-71)
Initializable._getInitializableStorage() (node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol#232-237) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol#234-236)
PausableUpgradeable._getPausableStorage() (node_modules/@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol#27-31) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol#28-30)
ReentrancyGuardUpgradeable._getReentrancyGuardStorage() (node_modules/@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol#49-53) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol#50-52)
SafeERC20._callOptionalReturn(IERC20,bytes) (node_modules/@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol#173-191) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol#176-186)
SafeERC20._callOptionalReturnBool(IERC20,bytes) (node_modules/@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol#201-211) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol#205-209)
Address._revert(bytes) (node_modules/@openzeppelin/contracts/utils/Address.sol#138-148) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/Address.sol#142-144)
StorageSlot.getAddressSlot(bytes32) (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#66-70) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#67-69)
StorageSlot.getBooleanSlot(bytes32) (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#75-79) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#76-78)
StorageSlot.getBytes32Slot(bytes32) (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#84-88) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#85-87)
StorageSlot.getUint256Slot(bytes32) (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#93-97) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#94-96)
StorageSlot.getInt256Slot(bytes32) (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#102-106) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#103-105)
StorageSlot.getStringSlot(bytes32) (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#111-115) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#112-114)
StorageSlot.getStringSlot(string) (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#120-124) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#121-123)
StorageSlot.getBytesSlot(bytes32) (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#129-133) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#130-132)
StorageSlot.getBytesSlot(bytes) (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#138-142) uses assembly
        - INLINE ASM (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#139-141)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#assembly-usage
INFO:Detectors:
9 different versions of Solidity are used:
        - Version constraint ^0.8.20 is used by:
                -^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol#4)
                -^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol#4)
                -^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/utils/ContextUpgradeable.sol#4)
                -^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol#4)
                -^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol#4)
                -^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/utils/introspection/ERC165Upgradeable.sol#4)
                -^0.8.20 (node_modules/@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol#4)
                -^0.8.20 (node_modules/@openzeppelin/contracts/utils/Address.sol#4)
                -^0.8.20 (node_modules/@openzeppelin/contracts/utils/Errors.sol#4)
                -^0.8.20 (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#5)
        - Version constraint ^0.8.22 is used by:
                -^0.8.22 (node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol#4)
        - Version constraint >=0.8.4 is used by:
                ->=0.8.4 (node_modules/@openzeppelin/contracts/access/IAccessControl.sol#4)
        - Version constraint >=0.6.2 is used by:
                ->=0.6.2 (node_modules/@openzeppelin/contracts/interfaces/IERC1363.sol#4)
        - Version constraint >=0.4.16 is used by:
                ->=0.4.16 (node_modules/@openzeppelin/contracts/interfaces/IERC165.sol#4)
                ->=0.4.16 (node_modules/@openzeppelin/contracts/interfaces/IERC20.sol#4)
                ->=0.4.16 (node_modules/@openzeppelin/contracts/interfaces/draft-IERC1822.sol#4)
                ->=0.4.16 (node_modules/@openzeppelin/contracts/proxy/beacon/IBeacon.sol#4)
                ->=0.4.16 (node_modules/@openzeppelin/contracts/token/ERC20/IERC20.sol#4)
                ->=0.4.16 (node_modules/@openzeppelin/contracts/utils/introspection/IERC165.sol#4)
        - Version constraint >=0.4.11 is used by:
                ->=0.4.11 (node_modules/@openzeppelin/contracts/interfaces/IERC1967.sol#4)
        - Version constraint ^0.8.21 is used by:
                -^0.8.21 (node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Utils.sol#4)
        - Version constraint 0.8.22 is used by:
                -0.8.22 (contracts/BuyBackBurnV2.sol#2)
                -0.8.22 (contracts/interfaces/IBuyBackBurnV2.sol#2)
                -0.8.22 (libraries/Constants.sol#2)
                -0.8.22 (libraries/Errors.sol#2)
        - Version constraint ^0.8.0 is used by:
                -^0.8.0 (interfaces/IRouter.sol#2)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#different-pragma-directives-are-used
INFO:Detectors:
Version constraint ^0.8.20 contains known severe issues (https://solidity.readthedocs.io/en/latest/bugs.html)
        - VerbatimInvalidDeduplication
        - FullInlinerNonExpressionSplitArgumentEvaluationOrder
        - MissingSideEffectsOnSelectorAccess.
It is used by:
        - ^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol#4)
        - ^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol#4)
        - ^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/utils/ContextUpgradeable.sol#4)
        - ^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol#4)
        - ^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol#4)
        - ^0.8.20 (node_modules/@openzeppelin/contracts-upgradeable/utils/introspection/ERC165Upgradeable.sol#4)
        - ^0.8.20 (node_modules/@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol#4)
        - ^0.8.20 (node_modules/@openzeppelin/contracts/utils/Address.sol#4)
        - ^0.8.20 (node_modules/@openzeppelin/contracts/utils/Errors.sol#4)
        - ^0.8.20 (node_modules/@openzeppelin/contracts/utils/StorageSlot.sol#5)
Version constraint ^0.8.22 contains known severe issues (https://solidity.readthedocs.io/en/latest/bugs.html)
        - VerbatimInvalidDeduplication.
It is used by:
        - ^0.8.22 (node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol#4)
Version constraint >=0.8.4 contains known severe issues (https://solidity.readthedocs.io/en/latest/bugs.html)
        - FullInlinerNonExpressionSplitArgumentEvaluationOrder
        - MissingSideEffectsOnSelectorAccess
        - AbiReencodingHeadOverflowWithStaticArrayCleanup
        - DirtyBytesArrayToStorage
        - DataLocationChangeInInternalOverride
        - NestedCalldataArrayAbiReencodingSizeValidation
        - SignedImmutables.
It is used by:
        - >=0.8.4 (node_modules/@openzeppelin/contracts/access/IAccessControl.sol#4)
Version constraint >=0.6.2 contains known severe issues (https://solidity.readthedocs.io/en/latest/bugs.html)
        - MissingSideEffectsOnSelectorAccess
        - AbiReencodingHeadOverflowWithStaticArrayCleanup
        - DirtyBytesArrayToStorage
        - NestedCalldataArrayAbiReencodingSizeValidation
        - ABIDecodeTwoDimensionalArrayMemory
        - KeccakCaching
        - EmptyByteArrayCopy
        - DynamicArrayCleanup
        - MissingEscapingInFormatting
        - ArraySliceDynamicallyEncodedBaseType
        - ImplicitConstructorCallvalueCheck
        - TupleAssignmentMultiStackSlotComponents
        - MemoryArrayCreationOverflow.
It is used by:
        - >=0.6.2 (node_modules/@openzeppelin/contracts/interfaces/IERC1363.sol#4)
Version constraint >=0.4.16 contains known severe issues (https://solidity.readthedocs.io/en/latest/bugs.html)
        - DirtyBytesArrayToStorage
        - ABIDecodeTwoDimensionalArrayMemory
        - KeccakCaching
        - EmptyByteArrayCopy
        - DynamicArrayCleanup
        - ImplicitConstructorCallvalueCheck
        - TupleAssignmentMultiStackSlotComponents
        - MemoryArrayCreationOverflow
        - privateCanBeOverridden
        - SignedArrayStorageCopy
        - ABIEncoderV2StorageArrayWithMultiSlotElement
        - DynamicConstructorArgumentsClippedABIV2
        - UninitializedFunctionPointerInConstructor_0.4.x
        - IncorrectEventSignatureInLibraries_0.4.x
        - ExpExponentCleanup
        - NestedArrayFunctionCallDecoder
        - ZeroFunctionSelector.
It is used by:
        - >=0.4.16 (node_modules/@openzeppelin/contracts/interfaces/IERC165.sol#4)
        - >=0.4.16 (node_modules/@openzeppelin/contracts/interfaces/IERC20.sol#4)
        - >=0.4.16 (node_modules/@openzeppelin/contracts/interfaces/draft-IERC1822.sol#4)
        - >=0.4.16 (node_modules/@openzeppelin/contracts/proxy/beacon/IBeacon.sol#4)
        - >=0.4.16 (node_modules/@openzeppelin/contracts/token/ERC20/IERC20.sol#4)
        - >=0.4.16 (node_modules/@openzeppelin/contracts/utils/introspection/IERC165.sol#4)
Version constraint >=0.4.11 contains known severe issues (https://solidity.readthedocs.io/en/latest/bugs.html)
        - DirtyBytesArrayToStorage
        - KeccakCaching
        - EmptyByteArrayCopy
        - DynamicArrayCleanup
        - ImplicitConstructorCallvalueCheck
        - TupleAssignmentMultiStackSlotComponents
        - MemoryArrayCreationOverflow
        - privateCanBeOverridden
        - SignedArrayStorageCopy
        - UninitializedFunctionPointerInConstructor_0.4.x
        - IncorrectEventSignatureInLibraries_0.4.x
        - ExpExponentCleanup
        - NestedArrayFunctionCallDecoder
        - ZeroFunctionSelector
        - DelegateCallReturnValue
        - ECRecoverMalformedInput
        - SkipEmptyStringLiteral.
It is used by:
        - >=0.4.11 (node_modules/@openzeppelin/contracts/interfaces/IERC1967.sol#4)
Version constraint ^0.8.21 contains known severe issues (https://solidity.readthedocs.io/en/latest/bugs.html)
        - VerbatimInvalidDeduplication.
It is used by:
        - ^0.8.21 (node_modules/@openzeppelin/contracts/proxy/ERC1967/ERC1967Utils.sol#4)
Version constraint 0.8.22 contains known severe issues (https://solidity.readthedocs.io/en/latest/bugs.html)
        - VerbatimInvalidDeduplication.
It is used by:
        - 0.8.22 (contracts/BuyBackBurnV2.sol#2)
        - 0.8.22 (contracts/interfaces/IBuyBackBurnV2.sol#2)
        - 0.8.22 (libraries/Constants.sol#2)
        - 0.8.22 (libraries/Errors.sol#2)
Version constraint ^0.8.0 contains known severe issues (https://solidity.readthedocs.io/en/latest/bugs.html)
        - FullInlinerNonExpressionSplitArgumentEvaluationOrder
        - MissingSideEffectsOnSelectorAccess
        - AbiReencodingHeadOverflowWithStaticArrayCleanup
        - DirtyBytesArrayToStorage
        - DataLocationChangeInInternalOverride
        - NestedCalldataArrayAbiReencodingSizeValidation
        - SignedImmutables
        - ABIDecodeTwoDimensionalArrayMemory
        - KeccakCaching.
It is used by:
        - ^0.8.0 (interfaces/IRouter.sol#2)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#incorrect-versions-of-solidity
INFO:Detectors:
Low level call in Address.sendValue(address,uint256) (node_modules/@openzeppelin/contracts/utils/Address.sol#33-42):
        - (success,returndata) = recipient.call{value: amount}() (node_modules/@openzeppelin/contracts/utils/Address.sol#38)
Low level call in Address.functionCallWithValue(address,bytes,uint256) (node_modules/@openzeppelin/contracts/utils/Address.sol#75-81):
        - (success,returndata) = target.call{value: value}(data) (node_modules/@openzeppelin/contracts/utils/Address.sol#79)
Low level call in Address.functionStaticCall(address,bytes) (node_modules/@openzeppelin/contracts/utils/Address.sol#87-90):
        - (success,returndata) = target.staticcall(data) (node_modules/@openzeppelin/contracts/utils/Address.sol#88)
Low level call in Address.functionDelegateCall(address,bytes) (node_modules/@openzeppelin/contracts/utils/Address.sol#96-99):
        - (success,returndata) = target.delegatecall(data) (node_modules/@openzeppelin/contracts/utils/Address.sol#97)
Low level call in BuyBackBurnV2.emergencyWithdraw() (contracts/BuyBackBurnV2.sol#131-140):
        - (success,None) = s_companyWallet.call{value: balOfEth}() (contracts/BuyBackBurnV2.sol#138)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#low-level-calls
INFO:Detectors:
Function AccessControlUpgradeable.__AccessControl_init() (node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol#83-84) is not in mixedCase
Function AccessControlUpgradeable.__AccessControl_init_unchained() (node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol#86-87) is not in mixedCase
Constant AccessControlUpgradeable.AccessControlStorageLocation (node_modules/@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol#66) is not in UPPER_CASE_WITH_UNDERSCORES
Function UUPSUpgradeable.__UUPSUpgradeable_init() (node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol#65-66) is not in mixedCase
Function UUPSUpgradeable.__UUPSUpgradeable_init_unchained() (node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol#68-69) is not in mixedCase
Variable UUPSUpgradeable.__self (node_modules/@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol#22) is not in mixedCase
Function ContextUpgradeable.__Context_init() (node_modules/@openzeppelin/contracts-upgradeable/utils/ContextUpgradeable.sol#18-19) is not in mixedCase
Function ContextUpgradeable.__Context_init_unchained() (node_modules/@openzeppelin/contracts-upgradeable/utils/ContextUpgradeable.sol#21-22) is not in mixedCase
Function PausableUpgradeable.__Pausable_init() (node_modules/@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol#77-78) is not in mixedCase
Function PausableUpgradeable.__Pausable_init_unchained() (node_modules/@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol#80-81) is not in mixedCase
Constant PausableUpgradeable.PausableStorageLocation (node_modules/@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol#25) is not in UPPER_CASE_WITH_UNDERSCORES
Function ReentrancyGuardUpgradeable.__ReentrancyGuard_init() (node_modules/@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol#60-62) is not in mixedCase
Function ReentrancyGuardUpgradeable.__ReentrancyGuard_init_unchained() (node_modules/@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol#64-67) is not in mixedCase
Constant ReentrancyGuardUpgradeable.ReentrancyGuardStorageLocation (node_modules/@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol#47) is not in UPPER_CASE_WITH_UNDERSCORES
Function ERC165Upgradeable.__ERC165_init() (node_modules/@openzeppelin/contracts-upgradeable/utils/introspection/ERC165Upgradeable.sol#22-23) is not in mixedCase
Function ERC165Upgradeable.__ERC165_init_unchained() (node_modules/@openzeppelin/contracts-upgradeable/utils/introspection/ERC165Upgradeable.sol#25-26) is not in mixedCase
Parameter BuyBackBurnV2.adjustUsdcToRwaRoute(bool,address)._aerodromeFactory (contracts/BuyBackBurnV2.sol#75) is not in mixedCase
Parameter BuyBackBurnV2.initialize(address,address,address,address)._usdc (contracts/BuyBackBurnV2.sol#96) is not in mixedCase
Parameter BuyBackBurnV2.initialize(address,address,address,address)._rwaToken (contracts/BuyBackBurnV2.sol#96) is not in mixedCase
Parameter BuyBackBurnV2.initialize(address,address,address,address)._companyWallet (contracts/BuyBackBurnV2.sol#96) is not in mixedCase
Parameter BuyBackBurnV2.initialize(address,address,address,address)._routerAddr (contracts/BuyBackBurnV2.sol#96) is not in mixedCase
Variable BuyBackBurnV2.s_usdc (contracts/BuyBackBurnV2.sol#24) is not in mixedCase
Variable BuyBackBurnV2.s_rwaToken (contracts/BuyBackBurnV2.sol#25) is not in mixedCase
Variable BuyBackBurnV2.s_companyWallet (contracts/BuyBackBurnV2.sol#26) is not in mixedCase
Variable BuyBackBurnV2.s_aerodromeFactory (contracts/BuyBackBurnV2.sol#27) is not in mixedCase
Variable BuyBackBurnV2.s_usdcToRwa (contracts/BuyBackBurnV2.sol#30) is not in mixedCase
Variable BuyBackBurnV2.s_totalBurnedRwaAmount (contracts/BuyBackBurnV2.sol#32) is not in mixedCase
Variable BuyBackBurnV2.__gap (contracts/BuyBackBurnV2.sol#146) is not in mixedCase
Function IBuyBackBurnV2.s_usdc() (contracts/interfaces/IBuyBackBurnV2.sol#11) is not in mixedCase
Function IBuyBackBurnV2.s_rwaToken() (contracts/interfaces/IBuyBackBurnV2.sol#12) is not in mixedCase
Function IBuyBackBurnV2.s_companyWallet() (contracts/interfaces/IBuyBackBurnV2.sol#13) is not in mixedCase
Function IBuyBackBurnV2.s_aerodromeFactory() (contracts/interfaces/IBuyBackBurnV2.sol#14) is not in mixedCase
Function IBuyBackBurnV2.s_usdcToRwa(uint256) (contracts/interfaces/IBuyBackBurnV2.sol#22-30) is not in mixedCase
Function IRouter.ETHER() (interfaces/IRouter.sol#54) is not in mixedCase
Function IRouter.UNSAFE_swapExactTokensForTokens(uint256[],IRouter.Route[],address,uint256) (interfaces/IRouter.sol#311-316) is not in mixedCase
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#conformance-to-solidity-naming-conventions
INFO:Detectors:
BuyBackBurnV2.__gap (contracts/BuyBackBurnV2.sol#146) is never used in BuyBackBurnV2 (contracts/BuyBackBurnV2.sol#19-147)
Reference: https://github.com/crytic/slither/wiki/Detector-Documentation#unused-state-variable
INFO:Slither:. analyzed (25 contracts with 100 detectors), 70 result(s) found