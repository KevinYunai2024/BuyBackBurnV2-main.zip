require("@nomicfoundation/hardhat-toolbox");
require("@openzeppelin/hardhat-upgrades");
require("@nomicfoundation/hardhat-verify");
require("dotenv").config();

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: "0.8.22",
  settings: { optimizer: { enabled: true, runs: 200 }, evmVersion: "paris" },
  networks: {
    base_sepolia: {
      url: "https://base-sepolia.infura.io/v3/c8b8880b688449e098c268f568bf7700",
      accounts: [process.env.PRIV_KEY],
    },
    base: {
      url: "https://base-mainnet.infura.io/v3/c8b8880b688449e098c268f568bf7700",
      accounts: [process.env.PRIV_KEY],
    },
  },
  etherscan: {
    apiKey: process.env.ETHERSCAN_API_KEY, // <- 只留这一行
  },
  sourcify: { enabled: false }, // 可选：去掉提示
};
